# StateMachine/stateMachine2/Transition.py
# Transition function object for state machine

class Transition:
    def transition(self, input):
        assert 0, "transition() not implemented"