# StateMachine/stateMachine2/Condition.py
# Condition function object for state machine

class Condition:
    boolean condition(input) :
        assert 0, "condition() not implemented"