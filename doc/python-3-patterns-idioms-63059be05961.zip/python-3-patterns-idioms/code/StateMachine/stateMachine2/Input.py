# StateMachine/stateMachine2/Input.py
# Inputs to a state machine

class Input: pass