# QuickPython/if.py
response = "yes"
if response == "yes":
    print("affirmative")
    val = 1
print("continuing...")