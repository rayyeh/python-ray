# PatternRefactoring/clip4.py
    for(int i = 0 i < 30 i++)
        bin.add(
          Trash.factory(
            Messenger(
              (int)(Math.random() * Messenger.MAX_NUM),
              Math.random() * 100)))