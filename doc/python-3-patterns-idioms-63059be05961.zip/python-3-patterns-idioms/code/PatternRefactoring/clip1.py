# PatternRefactoring/clip1.py
    for(int i = 0 i < 30 i++)
        switch((int)(Math.random() * 3)):
            case 0 :
                bin.add(new
                  Aluminum(Math.random() * 100))
                break
            case 1 :
                bin.add(new
                  Paper(Math.random() * 100))
                break
            case 2 :
                bin.add(new
                  Glass(Math.random() * 100))