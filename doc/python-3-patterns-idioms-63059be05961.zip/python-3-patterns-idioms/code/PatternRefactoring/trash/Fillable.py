# PatternRefactoring/trash/Fillable.py
# Any object that can be filled with Trash.

class Fillable:
    def addTrash(self, Trash t)