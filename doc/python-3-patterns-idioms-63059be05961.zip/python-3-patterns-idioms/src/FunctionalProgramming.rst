.. index::
   functional programming

********************************************************************************
Functional Programming
********************************************************************************

Further Reading
================================================================================

.. Series of articles on functional programming:
.. http://oubiwann.blogspot.com/2009/04/functional-programming-in-python.html
