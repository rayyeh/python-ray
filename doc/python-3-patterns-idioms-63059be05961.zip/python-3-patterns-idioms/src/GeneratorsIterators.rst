.. index::
   generators
   iterators
   itertools

********************************************************************************
Generators, Iterators, and Itertools
********************************************************************************

.. Infinite generators http://groups.google.com/group/comp.lang.python/browse_thread/thread/77cc9764f9d5a072
