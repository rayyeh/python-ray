options(object.size=10000000000, digits=6, scipen=100, memory=3200483647,contrasts=c("contr.treatment", "contr.poly"))


######
# numerical
x<-c(1/1, 1/2, 1/3, 1/4, 1/5)
x
# character
y<-c("Hello", "What's your name?", "Your email?")
y
# logicl
z<-c(F, T, T, F, F)
z
# complex
x.complex<-8+3i
x

#########
x <- 3; x + 5
y <- 1:10
#
{ x <- 3
    x + 5
    }
#




######################################
#
1+2
2*3+4
2*(3+4)
(3+11*2)/4

x.complex<-(8+3i)+(1+2i)
x.complex

#
x<-1:5
y<-6:10
z<-c(2,2,3,3,4)
x+y
x-y

x*2
x*y

x/2
x/y

x^2
x^z

y/2
y/x

x%*%y
y%*%x

x%x%y
y%x%x

y%%3
y%/%3
y%/%x

##########
x<-1:5
y<-6:10

x<2
x<=2
x==2
x!=2

x<y
x<(y-7)

x<=y
x<=(y-7)

x==y
x==(y-7)
x!=y
x!=(y-7)

##########
(x>0) & (y>0)
((x-2)>0) & ((y-7)>0)

(x>0) && (y>0)
((x-2)>0) && ((y-7)>0)

(x>0) | (y>0)
((x-2)>0) | ((y-7)>0)

(x>0) || (y>0)
((x-2)>0) || ((y-7)>0)


xor((x>0), (y>0))
xor(((x-2)>0), ((y-7)>0))

xx<-x<=1
yy<-x>4
xor(xx, yy)
xx | yy

####

#####################
# vector
x<-1:30
x
flavors<-c("chocolate", "vanilla", "strawberry")
flavors
z<-c(T, F, F)
z
## matrix
x<-c("a", "b", "c", "d")
x
y<-matrix(x,2,2)
y
y<-matrix(x,2,2,byrow=T)
y
## array
a<-1:24
a
b<-array(a, dim=c(2,3,4), dimnames=c("x", "y", "z"))
b

###### coerece
x<-c("hellp", 3+6i, 5.42, FALSE) # coerce to character
x
y<-c(3+6i, 5.42, FALSE) # coerce to complex
y
z<-c(5.42, FALSE) # coerce to numerical
z
##

###### recursive
# List
x<-1:4
y<-c("Male", "Female")
z<-matrix(1:9,3,3)
xyz.list<-list(x, y, z)
xyz.list
#
# get the elements in a list
xyz.list[1]
xyz.list[2]
xyz.list[3]
#
# give some names
xyz.list<-list(X=x, Y=y, Z=z)
xyz.list
xyz.list$X
xyz.list$Y
xyz.list$Z

### data frame
subjectid<-c(1, 2, 3, 4)
age<-c(35, 55, 45, 25)
sex<-c("Male", "Male", "Female", "Female")
disease<-c("Yes", "No", "No", "Yes")
x.data <- data.frame(subjectid, age, sex, disease)

mode(x.data)
class(x.data)


###############################
# mode, length and attributes
# vector
z<-1:100
mode(z)
length(z)
attributes(z)


# matrix
# matrix
x<-c("a", "b", "c", "d")
y<-matrix(x,2,2)
mode(x)
length(x)
dim(b)
attributes(x)

# array
a<-1:24
b<-array(a, dim=c(2,3,4), dimnames=c("x", "y", "z"))
mode(b)
length(b)
attributes(b)


# List
x<-1:4
y<-c("Male", "Female")
z<-matrix(1:9,3,3)
xyz.list<-list(x, y, z)
mode(xyz.list)
length(xyz.list)
attributes(xyz.list)

# data frame
subjectid<-c(1, 2, 3, 4)
age<-c(35, 55, 45, 25)
sex<-c("Male", "Male", "Female", "Female")

disease<-c("Yes", "No", "No", "Yes")
x.data <- data.frame(subjectid, age, sex, disease)
mode(x.data)
length(x.data)
ncol(x.data)
nrow(x.data)
dim(x.data)
attributes(x.data)
row.names(x.data)
names(x.data)
dimnamens(x.data)
str(x.data)


## attr
# create a 2 by 5 matrix
x <- 1:10
attr(x,"dim") <- c(2, 5)
x
#
y.str<-structure(matrix(c(1,2,3,4),nr=2,byrow=T),
  dimnames=list(c("row1","row2"),c("col1", "col2")))
y.str
dimnames(y.str)



###########################################3
# section: Vector

flavors<-c("chocolate", "vanilla", "strawberry")
flavors
�f��<-c("���J��", "����", "���")
�f��
scores<-c(5,5,5,3,6,2,4,5,3,4)
scores
y<-c(scores,0,0,scores)
y

##################
vector("character",5)
vector("complex",5)
vector("numeric",5)
vector("logical",5)
# vector("list",5)

character(5)
complex(5)
numeric(5)
logical(5)

##########
# seq()
1:5
5:1
seq(1, 2,0.3)
seq(from=1, to=5, by=0.5)
seq(1,5,length=3)
z<-c("a", "b", "c", "d", "e")
seq(along=z)
# the concatenated sequences 1:3, 1:4, 1:5.
sequence(c(3,4,5))
help(seq)

#############
# rep()
rep(1,5)
rep(0, times=10)
x<-c(1,2,3)
rep(x,each=2)
rep(x,times=2)
rep(x,times=c(2,2,2))
x<-c(1,2,3)
rep(x, times=c(1,2,3))
help(rep)

#######################
# gl()
# gl(n, k, length = n*k, labels = 1:n, ordered = FALSE)
## First control, then treatment:
gl(2, 3, label = c("Control", "Treat"))
## 20 alternating 1s and 2s
gl(2, 1, 5)
## alternating pairs of 1s and 2s
gl(2, 2, 5)

#######################
# paste()
paste("X", 1)
paste("X", "Y", 1)
paste("X", "Y", 1, sep="")
paste("X", "Y", 1:3, sep="")

paste(c("X", "Y"), 1)
paste(c("X", "Y"), 1, sep="")
paste(c("X", "Y"), 1:4, sep="")
paste(c("X", "Y"), 1:3, sep="")

paste(c("X", "Y"), 1:4, sep="", collapse=" + ")


#######################
#substr(x, start, stop)
substr("abcdef",2,4)
substring("abcdef",1:6,1:6)

substr(rep("abcdef",4),1:4,4:5)
x <- c("asfef", "qwerty", "xyz   ", "ab", "a")
substr(x, 2, 5)
substring(x, 2, 4:6)

substring(x, 2) <- c("..", "+++")
x

#
help(strsplit)
# split x on the letter e
x <- c(as = "asfef", qu = "qwerty", "xyz   ", "ab", "a")
strsplit(x,"e")





###############################
# arithmetic
###############
x<-c(0:4)
a<-1
y<-2 * (a+log(x))
y
y<-2 * (log(a+x))
y

####
## model change
x<-3+5i
mode(x)
y<-2
mode(y)
mode(c(x,y))
x+y
mode(x+y)





#############################
## logic
x<-1:5
y<-(x>2)
y

#####
x<-1:5
y<-6:10

x<2
x<=2
x==2
x!=2

x<y
x<(y-7)

x<=y
x<=(y-7)

x==y
x==(y-7)
x!=y
x!=(y-7)

##########
(x>0) & (y>0)
((x-2)>0) & ((y-7)>0)

(x>0) && (y>0)
((x-2)>0) && ((y-7)>0)

(x>0) | (y>0)
((x-2)>0) | ((y-7)>0)

(x>0) || (y>0)
((x-2)>0) || ((y-7)>0)


xor((x>0), (y>0))
xor(((x-2)>0), ((y-7)>0))

xx<-x<=1
yy<-x>4
xor(xx, yy)
xx | yy

####




#############
x<-c("hellp", 3+6i, 5.42, FALSE) # coerce to character
mode(x)
y<-c(3+6i, 5.42, FALSE) # coerce to complex
mode(y)
z<-c(5.42, FALSE) # coerce to numerical
mode(z)

#########
# length change
x<-1:3
2*x
y<-6:10
x+y





######
# missing value
z<-c(1:2,NA)
is.na(z)
log(z)
z/0
0/0
Inf-Inf


is.na(z)
is.na(0/0)
is.nan(z)
is.nan(0/0)

################
# complex
z<-c(3+5i, 5+1i,6+7i)
Re(z)
Im(z)
Mod(z)
Arg(z)



###########################
# Vector Indexing
# positive integer
x<-1:50
x[7]
x[11:15]
y<-x[11:15]
y

##  negative integer
z<-6:10
z[-c(2,4)]

## character string
fruit <- c(5, 10, 1, 20)
fruit
names(fruit) <- c("orange", "banana", "apple", "peach")
fruit
lunch <- fruit[c("apple","orange")]
lunch


## logical index
x<-c(NA, seq(-2,2), NA, seq(-2,2))
x
y<-x[!is.na(x)]
y
z<-x[x>0 & !is.na(x)]
z
x[x < (-5)]
y[y < (-5)]



##########################
# FACTOR OBJECT
# UNORDERED
sex <- factor(c("�k", "�k", "�k", "�k", "�k"))
sex
gender <- factor(c("Male", "Female", "Male", "Male", "Female"))
gender
levels(gender)

gender <- factor(c("M", "F", "M", "M", "F"), levels=c("M", "F"))
gender


gender <- factor(c("M", "F", "M", "M", "F"))
gender
levels(gender<-c("F", "M"))
gender

income <- factor(c("Lo", "Mid", "Hi", "Mid", "Lo", "Hi", "Lo"))
income
relevel(income, ref="Lo")
income



########################
# ORDERED
income <- ordered(c("Mid", "Hi", "Lo", "Mid", "Lo", "Hi", "Lo"))
income

inc <- ordered(c("Mid", "Hi", "Lo", "Mid", "Lo", "Hi", "Lo"),
    levels = c("Lo", "Mid", "Hi"))
inc


#######
### cut()
x<-1:12
y<-cut(x, breaks=4)
y

y<-cut(x, breaks=4, include.lowest=T, right=F, dig.lab=0)
y

y<-cut(x, breaks=seq(0,12,by=4))
y

y<-cut(x, breaks=c(0,4,8,12))
y

y<-ordered(y, labels=levels(y))
y

#
x<-1:12
y<-cut(x, breaks=5, include.lowest=T)
y

y<-ordered(y, labels=levels(y))
y

#########################
# Matrix
x<-matrix(c(1, 5, 3, 7, 4, 9), nrow=2)
x
x<-matrix(c(1, 5, 3, 7, 4, 9), nrow=2, byrow=T)
x
y<-matrix(c(1, 5, 3, 7, 4, 9), ncol=2)
y
y<-matrix(c(1, 5, 3, 7, 4, 9), ncol=2, byrow=T)
y
z<-matrix(1:18, nrow=3)
z

x.mat<-matrix(1:12, 3,4)
x.mat
class(x.mat)
dim(x.mat)



### Matrix index
x.mat<-matrix(c(1:12), 3, 4)
x
x.mat[2,3]<-30
x.mat
x.mat[2, ]
x.mat[ ,3]
x.mat[c(1,3), c(2,4)]

# rbind(), cbind()
x.vec<-c(1,2,3,4,5)
y.vec<-c(6,7,8,9,10)
rbind(x.vec, y.vec)
cbind(x.vec, y.vec)

x.mat<-matrix(c(11:20), 2, 5)
rbind(x.mat,x.vec)
cbind(x.mat,y.vec)


############################
## array
a.vec<-1:24
b.arr<-array(a.vec, dim=c(2,3,4), dimnames=c("x", "y", "z"))
dimnames(b.arr)<-list(letters[1:2],
      LETTERS[1:3],
      c("i", "ii", "iii", "iv"))
b.arr


mode(b.arr)
length(b.arr)
dim(b.arr)
attributes(b.arr)
class(b.arr)


##################################
# List
x<-1:4
y<-c("Male", "Female")
z<-matrix(1:9,3,3)
xyz.list<-list(x, y, z)
xyz.list

# get the elements in a list
xyz.list[1]
xyz.list[[1]]

xyz.list[2]
xyz.list[[2]]

xyz.list[3]
xyz.list[[3]]

# give some names
xyz.list<-list(class=x, gender=y, score=z)
xyz.list

xyz.list$class
xyz.list[["class"]]
xyz.list[["class"]][2]

xyz.list$gender
xyz.list[["gender"]][1]

xyz.list$score
xyz.list[["score"]][2,3]


