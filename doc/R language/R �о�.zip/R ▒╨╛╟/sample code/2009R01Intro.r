# R: �p���
15*13
3838+4949
88/3

# R: ø�ϻP����
z<-rchisq(1000,3)
hist(z)
plot(density(rchisq(1000,3)))

# 
x <- seq(from=1, to=2*pi, length=41)
y <- sin(x)
plot(x,y, col="red", cex=2)
lines(x,y, lwd=2)
#
x <- seq(from=1, to=2*pi, length=41)
y <- sin(x)
col <- c("red", "blue")
plot(x,y, col=col, cex=1:3, lwd=4) 
#
dev.print(png, "sin.png")
dev.print(postscript, "sin.ps")


# R: �έp�n��
sleep
## Classical example: Student's sleep data
plot(extra ~ group, data = sleep)
## Traditional interface
with(sleep, t.test(extra[group == 1], extra[group == 2]))
## Formula interface
t.test(extra ~ group, data = sleep)

# R: �έp�n��P�M��
x<-rnorm(20,1.5,2)
y<-x+rnorm(20)
cbind(y,x)
Summary(lm(y~x))
## R �έp�n��P�M��: �j�k���R
summary(lm(y~x))

# R: �{���y��
> mean.fun<-function(x){sum(x)/length(x)}

## R Build-In Function
> mean(x)

## Home Made Function
> mean.fun(x)


# �򥻼Ҧ��ܼƩR�W�P����
a < -49
sqrt(a)
b <- "The dog ate my homework"
sub("dog","cat",b)
x <- (1+1==3)
x
as.character(b)
x <- T
y <- F
x
y
#
a <- 5 
b <- sqrt(2)
a 
b
#
a <- "1" 
b <- 1
a 
b
#
a <- "character"
b <- "a"
x <- a
a 
b 
x
# NA not available
x <- c(1, 2, 3, NA)
x + 3
log(c(0, 1, 2))
0/0
#
1+NA
max(c(NA, 4, 7))
max(c(NA, 4, 7), na.rm=T)


�V�q, �x�}
x <- c(6,5,4,3,2,1)
x
sum(x)
x[c(1,3,5)]
x <- 6:1
x
x[1:3]
x[1:3]+x[6:4]
y <- c(0,10)
x+y
#
x <- matrix(1:18, nrow=3)
x
x[,3]
x[-1,4:6]
str(x)
#
X <- matrix(1:9, ncol=3, byrow=TRUE)
X
I <- diag(1, nrow=3)
I
I * X
I %*% X
         
# R: �V�q, �x�} �P �ʥ��� �۰ʸɻ�
x <- 7:1                
x              
y <- 1:3       
y              
x + y          
#
# Zero out every 2nd:
x <- 3:8           
y <- c(1,0)        
x * y              
x <- matrix(1:16, nrow=3)                                                  
x                                                                        
y <- c(-1,1)                                                             
# Multiply (moving down the columns)                                   
x * y                                                                    

# R: �V�q, �x�} �i�[�W �m�W ���� 
x <- c(87,76.3,1.67)
x
names(x) <- c("age", "weight", "height") 
x
# Alternatively
x <- c(age=87, weight=76.3, height=1.67)
x["age"]
bmi <- x["weight"]/x["height"]^2
# ���
x[1]                                               
bmi <- x[2]/x[3]^2
# R: �V�q, �x�} �i�[�W �ܼƦW�� ����
x1 <- c(87,76.3,1.67)
x2 <- c(78,96.3,1.84)
x3 <- c(45,62.9,1.54)
x <- matrix(c(x1,x2,x3), nrow=3, byrow=TRUE) 
x
# add variable names
colnames(x) <- c("age", "weight", "height")
rownames(x) <- c("jon", "kim", "dan")
x
x["jon",]
x[,c("weight","age")]
bmi <- x[,"weight"]/x[,"height"]^2
bmi

# �C�� Lists
x <- c(a=1:2, b=3, c=5:8)
x

x <- list(a=1:2, b=3, c=5:8)
x

x$a

x[["a"]]
x[2:3]

x[c("b","c")]
x <- list(a=1:4, b=4:6+2i, src="GenePix")
x


