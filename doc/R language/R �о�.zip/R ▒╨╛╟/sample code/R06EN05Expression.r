rm(list=ls(all=TRUE))
memory.limit(size = 2000)
options(digits=6, scipen=100, length=999,
        object.size=10000000000, memory=3200483647,
        contrasts=c("contr.treatment", "contr.poly"))
library(MASS)
library(survival)


setwd("X://temp//RData")

#################################
# if-else
(x<-1:5)
if (x[3] >= 3) print("x is greater than or equal to 3")
if (x[3] >= 3) print("x is greater than or equal to 3") else print("x is less than 3")
if (x[2] >= 3) print("x is greater than or equal to 3")
if (x > 3) print("x > 3") else print("x <= 3")

# if-else {}
(x<-1:5)
if (x[3] >= 3) {
       print("x is greater than 3")
       print("or x is equal to 3")
   } else{
        print("x is less than 3")
        print("x < 3")
      }

(x<-1:5)
if (x[2] >= 3) {
       print("x is greater than 3")
       print("or x is equal to 3")
   } else{
        print("x is less than 3")
        print("x < 3")
      }

# if-else assign
(x<-0:4)
if ( any(x <= 0) ) y<-log(1+x) else y<-log(x)
y
y <- if( any(x <= 0) ) log(1+x) else log(x)
y

# if-else && and ||
(x<-2:5)
if (all(x>0) && all(log(x))>0) {
  y <- log(log(x));
  print(cbind(x,y));
  } else{
  cat('some x <= 1, unable to do log(log(x))\n');
  }

# if-else && and ||
(x<-0:3)
if (all(x>0) && all(log(x))>0) {
  y <- log(log(x));
  print(cbind(x,y));
  } else{
  cat('some x <= 1, unable to do log(log(x))\n');
  }

# if-else nested


# ifelse()
(x<-seq(-2,2))
if(x>0) 1 else 0
y <- numeric(length(x))
y[x>0]<-1
y[x<=0]<-0
y
# ifelse()
(x<-seq(-2,2))
ifelse(x>0, 1,0)

####################
# switch(integer, ...)
x<-3
switch(x, 2+2, mean(1:10), rnorm(5))
switch(2, 2+2, mean(1:10), rnorm(5))
switch(6, 2+2, mean(1:10), rnorm(5))

(y<-rnorm(5))
test<-("median")
switch(test, mean = mean(y), median = median(y), sum = sum(y))
switch("mean", mean = mean(y), median = median(y), sum = sum(y))
switch("sum", mean = mean(y), median = median(y), sum = sum(y))


#############################
# for loop
#
x<-0
for(i in 1:5){
    x<-x+i
    cat("i=",i, ",", "x<-x+i=", x, "\n")
    }
#
(x<-1:5)
for(i in 1:length(x)){
    if(i > 1) {x[i]<-x[i-1]+x[i]}
    cat("i=",i, ",", "x[i]<-x[i]+x[i-1]=", x[i], "\n")
    }
    
    
#################################
# while()
(x<-1:5)
i<-1
while(i <= 5){
   if(i > 1) {x[i]<-x[i-1]+x[i]}
    cat("i=",i, ",", "x[i]<-x[i]+x[i-1]=", x[i], "\n")
    i<-i+1
    }
    
################################
# repeat()
(x<-1:5)
i<-1
repeat{
   if(i > 1) {x[i]<-x[i-1]+x[i]}
    cat("i=",i, ",", "x[i]<-x[i]+x[i-1]=", x[i], "\n")
    i<-i+1
    if (i > 5) break
    }


###################################333
# FUNCTION
# a simple example
f.hm<-function(x){x^3+x}
x<-1:5
f.hm(x)
f.hm(x/3)
f.hm(x/pi)

# derviative
f.hm.dev<-function(x){3*x^2+1}
x<-1:5
f.hm.dev(x)
f.hm.dev(x/3)
f.hm.dev(x/pi)

#######
# arguments
args(var)
args(f.hm)

#####
# arg. sequence
x.vec<-1:20
x.vec[3]<-NA
help(mean)
mean(x.vec)
mean(FALSE, x.vec)
mean(x.vec, 0.1, TRUE)
mean(x=x.vec, trim=0.1, na.rm=TRUE)
mean(na.rm=TRUE, x=x.vec, trim=0.1)

# arg. default
x.vec<-1:20
x.vec[3]<-NA
help(mean)
mean(x.vec)
mean(x=x, na.rm=TRUE)
mean(na.rm=TRUE, x=x.vec, trim=0.2)

###############
x.use<-rexp(20,rate=0.001)
x.use[c(4,13)]<-NA
fun.desc<-function(x.vec, na.use=TRUE, graph=TRUE){
  if(graph==TRUE){boxplot(x.vec)}
  x.num<-length(x.use)
  x.mis.num<-sum(is.na(x.use))
  x.use.num<-x.num-x.mis.num
  x.mean<-mean(x.vec, na.rm=na.use)
  x.med<-median(x.vec, na.rm=na.use)
  x.var<-var(x.vec, na.rm=na.use)
  x.min<-min(x.vec, na.rm=na.use)
  x.max<-max(x.vec, na.rm=na.use)
  x.rgn<-x.max-x.min
  cbind(x.num, x.mis.num, x.use.num,
        x.mean, x.med, x.var, x.min, x.max, x.rgn)
  }
  
fun.desc(x.vec, na.use=FALSE)

fun.desc(x.vec, graph=FALSE)

fun.desc(x.vec)

# compare R function: summary()
summary(x.vec)


#############################
# scope
x.glo<-20
f.hm<-function(x){
   x.local<-sqrt(20)
   x.glo<-x.local
   cat("local variable x.local =", x.local, "\n")
   cat("local variable x.glo =", x.glo, "\n")
   }
# local and global
f.hm(x.glo)
x.local
x.glo

#############################
# scope
x.glo<-20
f.hm<-function(x){
   x.local<-sqrt(20)
   assign("x.glo", x.local, env = .GlobalEnv)  # force assignment
   assign("y.local", x.local)
   z.local<<-x.local   # force assignment
   cat("local variable x.local =", x.local, "\n")
   cat("local variable y.local =", y.local, "\n")
   cat("local variable z.local =", z.local, "\n")
   cat("local variable x.glo =", x.glo, "\n")
   }
# local and global
f.hm(x.glo)
x.local  # not found
y.local  # not found
z.local  # found
x.glo    # value changed


#############################
# return as list
f.hm<-function(num){
    x.vec<-rexp(num, rate=0.001)
    y.mat<-matrix(c(rexp(num*num, rate=0.01)), nrow=num, byrow=T)
    list(xvec=x.vec, ymat=y.mat)
    }
f.list<-f.hm(5)
f.list$xvec
f.list$ymat

# return as list
f.hm<-function(num){
    x.vec<-rexp(num, rate=0.001)
    y.mat<-matrix(c(rexp(num*num, rate=0.01)), nrow=num, byrow=T)
    return(list(xvec=x.vec, ymat=y.mat))
    }
f.list<-f.hm(5)
f.list$xvec
f.list$ymat

# cat()
f.hm<-function(num){
    x.vec<-rexp(num, rate=0.001)
    cat(x.vec, "\n")
    cat(x.vec, sep=",", "\n")
    cat(x.vec, sep="\t", fill=50)
    cat(x.vec, sep="\n")
    cat(x.vec, file="X:\\temp\\Rdata\\xveccat.dat", sep="\n")
    write.table(x.vec, file="X:\\temp\\Rdata\\xvecwr.dat", sep=",", row.names=FALSE)
    x.df<-data.frame(xvec=x.vec, yvec=x.vec)
    write.table(x.df, file="X:\\temp\\Rdata\\xvecdf.dat", sep=",", row.names=FALSE)
    }
f.hm(5)

# readline()
f.hm.read<-function(){
    n.char<-readline("Enter a integer: ")
    num<-as.numeric(n.char) # readline treat as characters
    x.vec<-rexp(num, rate=0.001)
    cat(x.vec, "\n")
    }
f.hm.read()



#########################
# probability and random number
# normal distribution
pnorm(1.96)
qnorm(0.975)
dnorm(1.96)
rnorm(5, mean=0, sd=1)
rnorm(5, mean=3, sd=3)

# t distribution
qt(0.995, df=2)
2*pt(-1.96, df=2)
2*pt(-1.96, df=30)

# upper 1% point for an F(1, 2) distribution
sqrt(qf(0.99, 1, 2))

# Simulation different shapes of distribution
par(mfrow=c(2,2))
histSYM<-hist(rnorm(10000),nclas=100,freq=FALSE,
 	main="Symmetric Distribution", xlab="")
histFLAT<-hist(runif(10000),nclas=100,freq=FALSE,
 	main="Symmetric Flat Distribution", xlab="")
histSKR<-hist(rgamma(10000,shape=2,scale=1),freq=FALSE, nclas=100,
 	main="Skewed to Right", xlab="")
histSKL<-hist(rbeta(10000,8,2),nclas=100,freq=FALSE,
 	main="Skewed to Left", xlab="")
par(mfrow=c(1,1))

##
# seed
# uniform
runif(5)
runif(5)
set.seed(10)
runif(5)
set.seed(10)
runif(5)
# norm
rnorm(5)
rnorm(5)
set.seed(10)
rnorm(5)
set.seed(10)
rnorm(5)

################################
# sample
# a random sampling (permutation)
# sampling 5 subjects from 10 subjects
# without replacement
x<-1:10
sample(x, size=5, replace=FALSE)

# equal rpobability
x<-1:10
sample(x, size=5, replace=FALSE, prob=c(1:10))
sample(x, size=5, replace=FALSE, prob=c(rep(1,10)/10.0))

# unequal rpobability
y<-1:3
sample(y, size=2, replace=FALSE, prob=c(0.1, 0.6, 0.3))
sample(y, size=10, replace=TRUE, prob=c(0.25, 0.3, 0.45))


# clinical trials
# randomization
# random assign to two groups, total 20 subjects
# random assigning treatment groups
sample(2, size=20, replace=TRUE)

# random choose 10 subjects to group 1
sample(20, size=10, replace=FALSE)

# block randomization
# total 3 blocks, block size 4, choose 2 subjects to group 1
replicate(3, sample(c(1:4), size=2, replace=FALSE))

# bootstrap sampling -- only if length(x) > 1 !
sample(1:10,replace=TRUE)

# 20 Bernoulli trials
sample(c(0,1), size=20, replace=TRUE)

## More careful bootstrapping --  Consider this when using sample()
## programmatically (i.e., in your function or simulation)!
# sample()'s surprise -- example
x<-1:10
sample(x[x >  8]) # length 2
sample(x[x >  9]) # oops -- length 10!
try(sample(x[x > 10]))# error!




#####################
# R environment and options
> .First <- function() {
       options(prompt="$ ", continue="+\t")  # $ is the prompt
       options(digits=5, length=999)         # custom numbers and printout
       x11()                                 # for graphics
       par(pch = "+")                        # plotting character
       source(file.path(Sys.getenv("HOME"), "R", "mystuff.R"))
                                             # my personal functions
       library(MASS)                         # attach a package
     }


