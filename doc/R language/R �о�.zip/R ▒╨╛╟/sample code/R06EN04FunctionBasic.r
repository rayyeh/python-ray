rm(list=ls(all=TRUE))
memory.limit(size = 2000)
options(object.size=10000000000, digits=6, scipen=100, memory=3200483647,contrasts=c("contr.treatment", "contr.poly"))
library(survival)


setwd("X://temp//RData")

#############
x<-1:10
max(x)
min(x)
log(x)
mean(x)
sd(x)
summary(x)

#############
# Arithmethic Computing
# rounding
(x<- 0.5 + -2:4)
round(x) # IEEE rounding: -2  0  0  2  2  4  4
(y<-seq(-2, 4, by = 0.5))
(y.round<-round(y)) #-- IEEE rounding !
(y.trunc<-trunc(y))
(y.signif<-signif(y))
(y.ceil<-ceiling(y))
(y.floor<-floor(y))
cbind(y,y.round, y.trunc, y.signif, y.ceil, y.floor)


y[trunc(y) != floor(y)]
y[round(y) != floor(y + 0.5)]

(z <- pi * 100^(-1:3))
round(z, 3)
signif(z, 3)

options(digits=6, scipen=0)
print(z / 1000, digits=4)
options(digits=6, scipen=100)
print(z / 1000, digits=4)
zapsmall(z / 1000, digits=4)
zapsmall(exp(1i*0:4*pi/2))

##########################
sign(pi) # == 1
sign(-2:3)# -1 -1 0 1 1 1
abs(-2:3)

# log(), exp() calculation
(x<-1:3)
log(exp(x))
(y<-10^(x))
log10(y)
log10(1e7)# = 7

x <- 10^-(1+2*1:3)
cbind(x, log(1+x), log1p(x), exp(x)-1, expm1(x))

###########################
# combination
choose(5, 2)
for (n in 0:5) print(choose(n, k = 0:n))

factorial(100)
lfactorial(10000)

#############
(x.tri<-c(0, pi/2, pi, 3*pi/2))
sin(x.tri)
asin(sin(x.tri))


##############################
# all, any, which
x<-c(-1,-2,0,2,1)
all(x>0)
any(x>0)
which(x>0)
#
(X<-matrix(c(2,-1,-3, -1,2,4, -3,4,9), nrow=3, byrow=T))
 all(X>0)
any(X>0)
which(X>0)

which(X%%2==0)
which(X%%2==0, arr.ind=TRUE)
rownames(X)<-paste("Case",1:3, sep="_")
which(X%%2==0, arr.ind=TRUE)



###############################
# rank, sort and order
x<-c(7,9,6,10,8)
rev(x)
rank(x)
sort(x)  # from the smallest to the largest
order(x) # x[3] is the smallest one.

##########
x<-c(7,9,6,7,8)
rank(x, ties.method="average")
sort(x)
order(x)

###########
# ORDER
(x<-c(1, 1, 3:1, 1:4, 3))
(y<-c(9, 9:1))
(z<-c(2, 1:9))
(xyz.mat<-rbind(x,y,z))
xyz.order<-order(x,y,z)
xyz.mat[, xyz.order] # reordering (ties via 2nd & 3rd arg)
xyz.mat[, order(x,-y,z)] # descending order on y
xyz.mat[, order(y,z,x)]  # exercise
xyz.mat[, order(z,x,y)]  # exercise

(xyz.data<-data.frame(x,y,z))
xyz.data[order(x, -y, z), ]

## rearrange matched vectors so that the first is in ascending order
(x<-c(5:1, 6:8, 12:9))
(y<-(x-5)^2)
(z.o<- order(x))
rbind(x[z.o], y[z.o])
z.mat<-rbind(x,y)
z.mat[ , order(x,y)]


############################################
# Function for Character
# paste
paste(1:5) # same as as.character(1:5)
paste("A", 1:5, sep = "")
paste("A", 1:5, sep = " ")
paste("A", 1:5, sep = "#")
paste("Today is", date())
#
paste(c("X", "Y"), 1:5)
paste(c("X", "Y"), 1:5, sep = " ")
paste(c("X", "Y"), 1:5, sep = "")
paste(c("X", "Y"), 1:5, sep = "+")
paste(c("X", "Y"), 1:5, sep = "", collapse=" + ")
#
# update
# xy.temp<-paste(c("X", "Y"), 1:5, sep = "+")
# unpaste(xy.temp)

# substr()
data(state)
state.name[47:50]
substr(state.name[47:50], 1, 4)
substr(state.name[47:50], 1, 4)<-"AAA"
state.name[47:50]
#
# substring()
data(state)
state.name[47:50]
substring(state.name[47:50], first=3, last=1000)
substring(state.name[47:50], first=3, last=1000)<-"BBB"
state.name[47:50]
#
# abbreviate()
data(state)
state.name[47:50]
abbreviate(state.name[47:50],minlength=2, dot=TRUE)

#
# grep()
data(state)
state.name[47:50]
grep("Wa", state.name)




################################################
# Date
x.date<-c("2/28/1947", "12/10/1979", "1/1/1970")
x.date
#convert to Julian dates
x.julian<-as.Date(x.date, format="%m/%d/%Y")
x.julian
#display Julian dates as a numerical vector
as.numeric(x.julian)
julian(x.julian)

# Julian
weekdays(x.julian)
weekdays(x.julian, abbreviate=TRUE)
months(x.julian, abbreviate=FALSE)
quarters(x.julian, abbreviate=TRUE)
julian(x.julian)
# as.POSIXlt and as.POSIXct Object
as.POSIXlt(x.julian)
as.numeric(as.POSIXlt(x.julian))
as.POSIXct(x.julian)
as.numeric(as.POSIXct(x.julian))



# calculate age as of today's date
date.today<-Sys.Date()
x.age.error<-(date.today-x.julian)/365.25
x.age.error
# #the display of 'days' is not correct
# truncate number to get "age"
x.age.correct<-trunc(as.numeric(x.age.error))
x.age.correct
# create data frame
x.data<-data.frame(Birthday = x.date,
                   Standard = x.julian,
                   Julian = as.numeric(x.julian),
                   Age = x.age.correct)
x.data


######################################
######### date with input format
as.Date("1990-1-19") # standard format
as.Date("9/15/89", format="%m/%d/%y") # two digits for year
as.Date("4 25 92", format="%m %d %y")
as.Date("063095", format="%m%d%y")

# chinese GUI cause problems
as.Date("September 15, 1995", format="%B %d, %Y")
as.Date("27Aug95", format="%d%b%y") # two digits for year
as.Date("27Aug1995", format="%d%b%Y")
as.Date("September 15 1995", format="%B %d %Y")

## read in date info in format 'ddmmmyyyy'
## This will give NA(s) in some locales; setting the C locale
## as in the commented lines will overcome this on most systems.


# check local setting
## locale-specific version of date()
format(Sys.time(), "%a %b %d %X %Y %Z")

# change it
(lct <- Sys.getlocale("LC_TIME"))
Sys.setlocale("LC_TIME", "C")
format(Sys.time(), "%a %b %d %X %Y %Z")

# read it again
as.Date("September 15, 1995", format="%B %d, %Y")
as.Date("27Aug95", format="%d%b%y") # two digits for year
as.Date("27Aug1995", format="%d%b%Y")
as.Date("September 15 1995", format="%B %d %Y")
Sys.setlocale("LC_TIME", lct)

# date and time
## read in date/time info in format 'm/d/y h:m:s'
x.dates<-c("02/27/92", "02/27/92", "01/14/92")
x.times<-c("23:03:20", "22:29:56", "01:03:30")
x.datetime <- paste(x.dates, x.times)
strptime(x.datetime, "%m/%d/%y %H:%M:%S")

## time with fractional seconds
z.time <- strptime("20/2/06 11:16:16.683", "%d/%m/%y %H:%M:%OS")
z.time # prints without fractional seconds
op <- options(digits.secs=3)
z.time



#######################
# "survival" package
# as.date() without input format
as.date(c("28feb1947", "December 10 1979", "1Jan1970"))
as.date("9/15/89")
as.date("9-1-1990")
as.date("4 25 92")
as.date("063095")
as.date("27Aug95")
as.date("September 15 1995")

# survival package continuous time: day zero
as.numeric(as.date("1/1/1960"))
as.numeric(as.date("1/1/1970"))

# base package continuous time
as.numeric(as.Date("1960-1-1"))
as.numeric(as.Date("1970-1-1"))


####
# mdy.date()
mons<-c(2, 12, 5, 9)
days<-c(28, 10, 20, 9)
years<-c(1947, 1979, 2000, 2006)
s.date<-mdy.date(mons, days, years)
s.date
as.numeric(s.date)

###
# date.mdy()
s.date
date.mdy(s.date)
date.mdy(s.date, weekday=T)

# date.mmddyy(), date.ddmmmyy(), date.mmddyyyy()
date.mmddyy(s.date)
date.ddmmmyy(s.date)
date.mmddyyyy(s.date)



##################################
# STAT
(x<-seq(-2, 3, 0.3))
sum(x)
cumsum(x)
diff(x)
prod(x)
cumprod(x)
mean(x)
median(x)
var(x)
sd(x)
range(x)
min(x)
max(x)
(y<-quantile(x, probs=c(0.05, 0.25, 0.5, 0.75, 0.95)))
# quantile range
y[4]-y[2]

# five numbers
fivenum(x)

# missing values
x[3]<-NA
x[7]<-NA
x
mean(x)
mean(na.omit(x))
var(x, na.rm=T)

#########################################
# MATRIX ALGEBRA
#########################################

# matrix + and -
(A<-matrix(c(1:12),nrow=3, byrow=T))
(B<-matrix(c(1:12),nrow=3))
A+B
A-B

# transpose
A<-matrix(c(1:12),nrow=3, byrow=T)
t(A)

# aperm()
A<-matrix(c(1:12),nrow=3, byrow=T)
(B.aperm<-aperm(A, c(2,1))) # = t(A) = matrix transpose

## aperm array
a.vec<-1:24
b.arr<-array(a.vec, dim=c(2,3,4), dimnames=c("x", "y", "z"))
dimnames(b.arr)<-list(letters[1:2],LETTERS[1:3],c("i", "ii", "iii", "iv"))
b.arr
aperm(b.arr,c(2,3,1))


###############
# product: scalar
A<-matrix(c(1:12),nrow=3, byrow=T)  # A_(3x4)
A*2

###############
# product: element by element
(A<-matrix(c(1:12),nrow=3, byrow=T)) # A_(3x4)
(B<-matrix(c(1:12),nrow=3))          # B_(3x4)
A*B

###############
# product: division: /
(A<-matrix(c(1:12),nrow=3, byrow=T)) # A_(3x4)
(B<-matrix(c(1:12),nrow=3))          # B_(3x4)
A/B


###############
# product: inner %*%
(A<-matrix(c(1:12),nrow=3, byrow=T)) # A_(3x4)
(B<-matrix(c(1:8),nrow=4))           # B_(4x2)
A%*%B                                # C_{3x2}


###############
# product: outer %o%
(A<-matrix(c(1:6),nrow=3)) # A_(3x2)
(B<-matrix(c(1:4),nrow=2)) # B_(2x2)
A%o%B
B%o%A

###############
# product: outer %x%
A<-matrix(c(1:6),nrow=3) # A_(3x2)
B<-matrix(c(1:4),nrow=2) # B_(2x2)
A%x%B
B%x%A

###############
# product: outer  kronecker
A<-matrix(c(1:6),nrow=3) # A_(3x2)
B<-matrix(c(1:4),nrow=2) # B_(2x2)
kronecker(A, B)
kronecker(B, A)


#####
# product: crossproduct()
A<-matrix(c(1:6),nrow=3) # A_(3x2)
B<-matrix(c(1:6),nrow=3) # B_(3x2)
crossprod(A,B)
t(A) %*% B

###############
# product: power "^"
A<-matrix(c(1:9),nrow=3) # square matrix A_(3x3)
A^3

######
# det()
(A<-matrix(c(1,2,3, 2,3,4, 3,4,1), nrow=3, byrow=T))
det(A)
determinant(A, logarithm=FALSE)
(B<-matrix(c(3,1,4,-2), nrow=2, byrow=T))
det(B)
determinant(B, logarithm=FALSE)


#########
# diag()
(A<-matrix(c(1:9),nrow=3)) # square matrix A_(3x3)
diag(A)
diag(rep(2,3))
diag(3)

(B<-matrix(c(1:6),nrow=3)) # B_(3x2)
diag(B)

(B<-matrix(c(1:6),nrow=2)) # B_(2x3)
diag(B)

###############
# inverse, linear equation
(A<-matrix(c(1,2,3, 2,3,4, 3,4,1), nrow=3, byrow=T))
(b<-c(3,0,1))
solve(A)
round(solve(A)%*%A,2)
x<-solve(A,b)
A%*%x


###################
# eigen valves and vectors
# options(object.size=10000000000, digits=6, scipen=100, memory=3200483647,contrasts=c("contr.treatment", "contr.poly"))
(A<-matrix(c(1,2,3, 2,3,4, 3,4,1), nrow=3, byrow=T))
A.eig<-eigen(A)
A.eig$values
A.eig$vectors
# determinant
prod(eigen(A)$valves)
det(A)

###################
# SVD
(A<-matrix(c(1,2,3, 2,3,4, 3,4,1), nrow=3, byrow=T))
b.svd<-svd(A)
b.svd$d
b.svd$u
b.svd$v
# determinant
det (A)
prod(svd(A)$d)


###################
# QR
(X<-matrix(c(1,2,3, 2,3,4, 3,4,1), nrow=3, byrow=T))
(Xqr<-qr(X))
(X.back<-qr.X(Xqr))
(R.back<-qr.R(Xqr))
(Q.back<-qr.Q(Xqr))
Q.back%*%R.back

##########################
# Choleski Decomposition
(X<-matrix(c(2,-1,-3, -1,2,4, -3,4,9), nrow=3, byrow=T))
# (X.chol<-chol(X, pivot=TRUE))
(X.chol<-chol(X))
t(X.chol)%*%X.chol
crossprod(X.chol)


##########################
# table()
xvec<-c(rep(0,5), rep(1,7), rep(2,6), rep(3,6))
yvec<-rep(c(1,0), 12)
zvec<-rep(c(1,2), times=c(12,12))
xyz.data<-data.frame(xdat=xvec, ydat=yvec, zdat=zvec)
xyz.data
attach(xyz.data)

xy.tab<-table(xdat, ydat)
xy.tab
xyz.tab<-table(xdat, ydat, zdat)
xyz.tab
# ftable()
xy.ftab<-ftable(xdat, ydat)
xy.ftab
xyz.ftab<-ftable(xdat, ydat, zdat)
xyz.ftab
# xtabs()
xy.xtabs<-xtabs(~xdat+ydat)
xy.xtabs
xyz.xtabs<-xtabs(~xdat+ydat+zdat)
xyz.xtabs
# as.data.frame
xy.as<-as.data.frame(xy.xtabs)
xy.as
xyz.as<-as.data.frame(xyz.xtabs)
xyz.as
# margin.table(), prop.table()
margin.table(xy.tab, margin=1)
prop.table(xy.tab, margin=1)

margin.table(xyz.tab, margin=2)
prop.table(xyz.tab, margin=2)

margin.table(xyz.tab, margin=c(1,2))

margin.table(xy.ftab, margin=1)       # not work
margin.table(xyz.ftab, margin=2)      # not work
margin.table(xyz.ftab, margin=c(1,2)) # not work

margin.table(xy.xtabs, margin=1)
prop.table(xy.xtabs, margin=1)

margin.table(xyz.xtabs, margin=2)
prop.table(xyz.xtabs, margin=2)

# margin.table(xyz.xtabs, margin=c(1,2)) # not work

# colMean()
colSums(xyz.data, na.rm = FALSE, dims=1)
rowSums(xyz.data, na.rm = FALSE, dims=1)

colMeans(xyz.data, na.rm = FALSE, dims=1)
round(rowMeans(xyz.data, na.rm = FALSE, dims=1), digits=2)

rowsum(xyz.data, zdat)
rowsum(xyz.data, ydat)
rowsum(xyz.data, xdat)

####################################
# apply() and array
a<-1:48
b.arr<-array(a, dim=c(4,3,4), dimnames=c("x", "y", "z"))
b.arr
b.arr[1,  , ]
mean(b.arr[1,  , ])

b.arr[ , 2, ]
mean(b.arr[ , 2, ])

b.arr[ ,  ,3]
mean(b.arr[ ,  ,3])

# matrix, data
a<-1:48
b.data<-as.data.frame(matrix(a, nrow=12, byrow=T))
b.data

# apply()
apply(b.arr, 1, mean)
apply(b.arr, 2, mean)
apply(b.arr, 3, mean)

apply(b.data, 1, mean)
apply(b.data, 2, mean)

# lapply(), sallpy(), replicate()
# list + lapply()
c.list<-list(a=1:20,
             beta=exp(-2:2),
             logic=c(TRUE,FALSE,FALSE,TRUE,FALSE))
lapply(c.list, mean)
lapply(b.data, mean)
# list + sapply()
sapply(c.list, mean, simplify=FALSE)
sapply(c.list, mean, simplify=TRUE)
sapply(b.data, mean) # for each variable in a data.frame

# replicate
replicate(5, rexp(10))
replicate(5, mean(rexp(10)))

# tapply()
x.vec<-1:12
y.group<-c(1,2,1,1,2,2,1,1,1,1,1,1)
cbind(x.vec, y.group)
tapply(x.vec, y.group, mean)

# data + tapply()
b.data<-as.data.frame(matrix(c(1:48), nrow=12, byrow=T))
b.data<-transform(b.data, sex=rep(c(1:2),6), race=rep(c(1:3),4))
b.data
sapply(b.data, tapply, b.data$sex, mean) # not easy to understand

######
# mapply()
mapply(rep, 1:3, 3:1)
mapply(rep, times=1:3, x=3:1)
mapply(rep, times=1:3, MoreArgs=list(x=7))
# Vectorize()
vrep<-Vectorize(rep)
vrep(1:3, 3:1)
vrep(times=1:3, x=3:1)
vrep<-Vectorize(rep, "times")
vrep(times=1:3, x=7)


# by
b.data<-as.data.frame(matrix(c(1:48), nrow=12, byrow=T))
b.data<-transform(b.data, sex=rep(c(1:2),6), race=rep(c(1:3),4))
by(b.data, b.data$sex, mean)
#
sapply(b.data, tapply, b.data$sex, mean) # not easy to understand

# sweep()
b.data<-as.data.frame(matrix(c(1:48), nrow=12, byrow=T))
b.mean<-apply(b.data,2,mean)
sweep(b.data,2,b.mean)


# aggregate()
b.data<-as.data.frame(matrix(c(1:48), nrow=12, byrow=T))
b.data<-transform(b.data, sex=rep(c(1:2),6), race=rep(c(1:3),4))
aggregate(b.data, by=list(SEX=b.data$sex), mean)
# compare by() and sapply()
by(b.data, b.data$sex, mean)
# sapply() not easy to understand
sapply(b.data, tapply, b.data$sex, mean)


###################
# is() and as()
xvec<-1:12
is.vector(xvec)
is.character(xvec)

b.data<-as.data.frame(matrix(c(1:48), nrow=12, byrow=T))
b.data<-transform(b.data, sex=rep(c(1:2),6), race=rep(c(1:3),4))
is.matrix(b.data)
b.mat<-as.matrix(b.data)
b.mat
as.vector(b.mat)
as.factor(b.data$sex)



##############################################
# split() merge()

# split
# input data
# Therapy Sex Age TC1 TC2 FBS1 FBS2
CTDM.df<-read.table("CTDMInsu.csv",header=TRUE,row.names=NULL,sep=",",dec=".")
CTDM.df
attach(CTDM.df)

x.vec<-c(1:6)
x.vec[c(5, 6)]<-NA
x.f1<-rep(c(1,2),3)
x.f2<-rep(c(1,2), each=3)
x.f3<-rep(c(1,2,3), length.out=6)
x.df<-data.frame(x.vec=x.vec, x.f1=x.f1, x.f2=x.f2, x.f3=x.f3)
x.df
#
x.split<-split(x.df, as.factor(x.f1))
x.split
#
# merge
x.vec<-c(1:6)
x.f1<-rep(c(1,2),3)
x.f2<-rep(c(1,2), each=3)
x.f3<-rep(c(1,2,3), length.out=6)
x.df<-data.frame(x.vec=x.vec, x.f1=x.f1, x.f2=x.f2, x.f3=x.f3)
x.df
#
y.vec<-c(3:8)
x.f1<-rep(c(1,2),3)
y.f2<-rep(c(1,2), each=3)
y.f3<-rep(c(1,2,3,4), length.out=6)
y.df<-data.frame(y.vec=y.vec, x.f1=x.f1, y.f2=y.f2, y.f3=y.f3)
y.df
#
merge(x.df, y.df, by.x="x.vec", by.y="y.vec", sort=FALSE)
merge(x.df, y.df, by.x="x.vec", by.y="y.vec", all=TRUE, sort=FALSE)
merge(y.df, x.df, by.x="y.vec", by.y="x.vec", all=TRUE, sort=TRUE)
merge(x.df, y.df, by.x="x.vec", by.y="y.vec",
      sort=FALSE, all=TRUE, suffixes = c(".X",".Y"))
      
      