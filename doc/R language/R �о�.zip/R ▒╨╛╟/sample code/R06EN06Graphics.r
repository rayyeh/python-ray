rm(list=ls(all=TRUE))
memory.limit(size = 2000)
options(digits=6, scipen=100, length=999)

library(MASS)
library(Hmisc)
# library(Design)
library(survival)

setwd("X://temp//RData")

options(digits=6, scipen=100, length=999,
        object.size=10000000000, memory=3200483647,
        contrasts=c("contr.treatment", "contr.poly"))
l
#####################################################
# a simple session
###################

# High-level Plot: Univariate
## simulated standard normal distribution
setps(RGraphNormSimple, h=8, w=6)
# setpdf(RGraphNormSimple, h=8, w=6)
par(mfrow = c(3,2))

x.norm<-rnorm(100,mean=0,sd=1)
x.group<-sample(c(1:4), 100, replace=TRUE)
x.cat<-sample(c(1:8), 100, replace=TRUE, prob=c(8:1))
x.cat.tab<-table(x.cat)

barplot(x.cat.tab)
pie(x.cat.tab)
hist(x.norm)
boxplot(x.norm)
qqnorm(x.norm)
plot(density(x.norm))

par(mfrow = c(1,1))
dev.off()



##################################
# High-level Plot: Bivariate

# input data
# Therapy Sex Age TC1 TC2 FBS1 FBS2
CTDM.df<-read.table("CTDMInsu.csv",
    header=TRUE, row.names=NULL,
    sep=",", dec=".")
CTDM.df
attach(CTDM.df)

plot(FBS1, FBS2)  # Bivariate scatter plot
plot(FBS1, FBS2, xlab="FBS1",
    ylab="FBS2",
    main="FBS2 vs. FBS1")
lines(supsmu(FBS1, FBS2))
plot(as.factor(Therapy), (FBS2-FBS1)) # Box plot by a factor
boxplot((FBS2-FBS1)~Therapy)          # Box plot by a factor

# High-level Plot: Multivariate
pairs(~FBS2+FBS1+TC2+TC1) # Pairwise plots


############
# simple example
# Low-level Plot and regression lines
setps(RGraphCTDMsimpleLM, h=3, w=8)
# setpdf(RGraphCTDMsimpleLM, h=3, w=8)
par(mfrow = c(1,2))

plot(FBS2 ~ FBS1, type = "n",
     main = "FBS: 12-month therapy vs. baseline",
     xlab = "FBS: baseline", ylab = "FBS: 12-month therapy")

points(FBS1[Therapy == 1], FBS2[Therapy == 1], pch = 1)
points(FBS1[Therapy == 2], FBS2[Therapy == 2], pch = 19)

abline(lm(FBS2 ~ FBS1, data = CTDM.df[Therapy == 1,]), lty=1, lwd=1.5)
abline(lm(FBS2 ~ FBS1, data = CTDM.df[Therapy == 2,]), lty=2, lwd=1.5)
legend(130,130, c("Syn. ","Reg."),
       pch=c(1,19), lty=1:2, lwd=1.5)

##
# can not use chinese in PS

plot((FBS2-FBS1) ~ FBS1, type = "n",
     main = "FBS(12-mo Tx - baseline) vs. baseline",
     xlab = "FBS: baseline", ylab = "FBS(12-mo Tx - baseline)")

points(FBS1[Therapy == 1], (FBS2-FBS1)[Therapy == 1], pch = 1)
points(FBS1[Therapy == 2], (FBS2-FBS1)[Therapy == 2], pch = 19)

abline(lm((FBS2-FBS1) ~ FBS1, data = CTDM.df[Therapy == 1,]), lty=1, lwd=1.5)
abline(lm((FBS2-FBS1) ~ FBS1, data = CTDM.df[Therapy == 2,]), lty=2, lwd=1.5)
legend(165,-30, c("Syn.","Reg."),
       pch=c(1,19), lty=1:2, lwd=1.5)



par(mfrow = c(1,1))
dev.off()


#####################################################
# SECTION: high-level plot
CTDM.df<-read.table("CTDMInsu.csv",
    header=TRUE, row.names=NULL,
    sep=",", dec=".")
attach(CTDM.df)

##
setps(RGraphCTDMHIALL, h=6, w=6)
# setpdf(RGraphCTDMHIALL, h=6, w=6)
par(mfrow = c(3,3))

# common high-level plot examples
dotchart(FBS2, main="dotchart()")
hist(FBS2,  main="hist()")
barplot(FBS2, main="barplot()")
boxplot(FBS2, main="boxplot()")
plot(FBS2, FBS1, main="plot()")
qqnorm(FBS2, main="qqnorm()")

# 3-D plot
# volcano data
#  Maunga Whau (Mt Eden) is one of about 50 volcanos in the Auckland
#   volcanic field.  This data set gives topographic information for
#   Maunga Whau on a 10m by 10m grid.
# matrix 87 x 61

x.volc<-10*(1:nrow(volcano))
y.volc<-10*(1:ncol(volcano))
contour(x.volc, y.volc, volcano, main="contour()")
image(x.volc, y.volc, volcano, main="image()")
persp(x.volc, y.volc, volcano, main="persp()")

par(mfrow = c(1,1))
dev.off()



#############
# subsection
# plot()
CTDM.df<-read.table("CTDMInsu.csv",
    header=TRUE, row.names=NULL,
    sep=",", dec=".")
CTDM.df
attach(CTDM.df)
#
plot(TC1, TC2)
#
plot(as.factor(Therapy))
plot(as.factor(Therapy), TC2-TC1)

#
setps(RGraphCTDMplotData, h=6, w=6)
# setpdf(RGraphCTDMplotData, h=6, w=6)
par(mfrow = c(1,1))
plot(CTDM.df)
par(mfrow = c(1,1))
dev.off()


#
setps(RGraphCTDMplotMult, h=6, w=6)
# setpdf(RGraphCTDMplotMult, h=6, w=6)
par(mfrow = c(1,1))
plot(~ TC1 + TC2 + as.factor(Therapy))
par(mfrow = c(1,1))
dev.off()

#
setps(RGraphCTDMplotModel, h=3, w=8)
# setpdf(RGraphCTDMplotModel, h=3, w=8)
par(mfrow = c(1,2))
plot((TC2-TC1) ~ TC1 + as.factor(Therapy))  # two plots

par(mfrow = c(1,1))
dev.off()



#######################################
# subsection
# high-level arguments
# type

CTDM.df<-read.table("CTDMInsu.csv", header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)

#
setps(RGraphCTDMHLtype, h=6, w=6)
# setpdf(RGraphCTDMHLtype, h=6, w=6)

par(mfrow = c(3,3))
FBS.diff<-FBS2-FBS1
CTDM.id<-c(1:32)
plot(CTDM.id, FBS.diff, type="p", main='type="p"', bty="o")
plot(CTDM.id, FBS.diff, type="l", main='type="l"', bty="o")
plot(CTDM.id, FBS.diff, type="b", main='type="b"', bty="o")
plot(CTDM.id, FBS.diff, type="s", main='type="s"', bty="o")
plot(CTDM.id, FBS.diff, type="S", main='type="S"', bty="o")
plot(CTDM.id, FBS.diff, type="o", main='type="o"', bty="o")
plot(CTDM.id, FBS.diff, type="h", main='type="h"', bty="o")
plot(CTDM.id, FBS.diff, type="n", main='type="n"', bty="o")

par(mfrow = c(1,1))

dev.off()



#######################################
# subsection
# high-level arguments
# bty (box types)



setps(RGraphCTDMHLbty, h=6, w=5)
# setpdf(RGraphCTDMHLbty, h=6, w=5)

par(mfrow = c(3,2))
FBS.diff<-FBS2-FBS1
CTDM.id<-c(1:32)
plot(CTDM.id, FBS.diff, type="p", main='bty="o"', bty="o")
plot(CTDM.id, FBS.diff, type="l", main='bty="l"', bty="l")
plot(CTDM.id, FBS.diff, type="b", main='bty="7"', bty="7")
plot(CTDM.id, FBS.diff, type="s", main='bty="c"', bty="c")
plot(CTDM.id, FBS.diff, type="S", main='bty="u"', bty="u")
plot(CTDM.id, FBS.diff, type="o", main='bty="]"', bty="]")

par(mfrow = c(1,1))

dev.off()



#############
# subsection
# pch

setps(RGraphCTDMHLpch, h=4, w=6)
# setpdf(RGraphCTDMHLpch, h=4, w=6)

par(mfrow = c(1,1))

     ##-------- Showing all the extra & some char graphics symbols ------------
     Pex <- 3 ## good for both .Device=="postscript" and "x11"
     ipch <- 0:35; np <- length(ipch); k <- floor(sqrt(np)); dd <- c(-1,1)/2
     rx <- dd + range(ix <- ipch %/% k)
     ry <- dd + range(iy <- 3 + (k-1)- ipch %% k)
     pch <- as.list(ipch)
     pch[26+ 1:10] <- as.list(c("*",".", "o","O","0","+","-","|","%","#"))
     plot(rx, ry, type="n", axes = FALSE, xlab = "", ylab = "",
          main = paste("plot symbols :  points (...  pch = *, cex =", Pex,")"))
     abline(v = ix, h = iy, col = "lightgray", lty = "dotted")
     for(i in 1:np) {
       pc <- pch[[i]]
       points(ix[i], iy[i], pch = pc, col = "black", bg = "gray70", cex = Pex)
       ## black symbols with a grapy70 interior (where available)
       text(ix[i] - .3, iy[i], pc, col = "blue", cex = 1.2)
     }


par(mfrow = c(1,1))

dev.off()








#########################################
#########################################
#########################################
#############
# subsection
# lty and pwd

setps(RGraphCTDMHLltylwd, h=5, w=5)
# setpdf(RGraphCTDMHLltylwd, h=5, w=5)

par(mfrow = c(1,1))

x<--1:22
y<--1:22
plot(x,y, type="n", ann=FALSE, axes=FALSE, frame.plot=TRUE, bty="o")

# lty
text(5, 22, adj=1, labels="lty", cex=1.5)
text(rep(0,20), c(20:1), adj=1, labels=as.character(c(1:20)))
for (i in c(seq(20,1,by=-1))){
  lines(c(2,9), c(i,i), lty=21-i, lwd=2.0)
  }
  
  
# lwd
text(16, 22, adj=1, labels="lwd", cex=1.5)
text(rep(12,20), c(20:1), adj=0, labels=as.character(c(1:20)/4.0))
for (i in 1:20){
  lines(c(14,21), c(i,i), lty=1, lwd=(21-i)/4.0)
  }

par(mfrow = c(1,1))

dev.off()


########################################
# subsection
# comp High-Level plot arguments

CTDM.df<-read.table("CTDMInsu.csv", header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)
#

setps(RGraphCTDMHLArg, h=6, w=4)
# setpdf(RGraphCTDMHLArg, h=6, w=4)
par(mfrow = c(2,1))

# default
plot(TC1, TC2-TC1)

# plus some common arguments
plot(TC1[order(TC1)], (TC2-TC1)[order(TC1)],
       type = "b",
       bty  = "o",
       pch = 19,
       lty = 2,
       cex = 1.5,
       lwd = 1.5,
       xlim = c(200, 320), ylim = c(-100, 20),
       main = "TC diff. (= TC2-TC1) vs. TC1",
       sub = "High-level plot with arguments",
       xlab = "TC at baseline", ylab = "TC diff. (= TC2-TC1)",
       axes = TRUE,
       ann=TRUE,
       frame.plot=TRUE
       )
       
par(mfrow = c(1,1))
dev.off()




#####################################################
# SECTION:
# other high-level plots
# high-level plot
CTDM.df<-read.table("CTDMInsu.csv",
    header=TRUE, row.names=NULL,
    sep=",", dec=".")
attach(CTDM.df)

##
setps(RGraphCTDMHIALL, h=6, w=6)
# setpdf(RGraphCTDMHIALL, h=6, w=6)
par(mfrow = c(3,3))

# common high-level plot examples
dotchart(FBS2, main="dotchart()")
hist(FBS2,  main="hist()")
barplot(FBS2, main="barplot()")
boxplot(FBS2, main="boxplot()")
plot(FBS2, FBS1, main="plot()")
qqnorm(FBS2, main="qqnorm()")

# 3-D plot
# volcano data
#  Maunga Whau (Mt Eden) is one of about 50 volcanos in the Auckland
#   volcanic field.  This data set gives topographic information for
#   Maunga Whau on a 10m by 10m grid.
# matrix 87 x 61

x.volc<-10*(1:nrow(volcano))
y.volc<-10*(1:ncol(volcano))
contour(x.volc, y.volc, volcano, main="contour()")
image(x.volc, y.volc, volcano, main="image()")
persp(x.volc, y.volc, volcano, main="persp()")

par(mfrow = c(1,1))
dev.off()



#############
# subsection
# multivariate plot
CTDM.df<-read.table("CTDMInsu.csv", header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)

##
# setps(RGraphCTDMHIcoplot01, h=4, w=5)
# setpdf(RGraphCTDMHIcoplot01, h=4, w=5)
# par(mfrow = c(1,1))
coplot(FBS2~FBS1 | Therapy)
# par(mfrow = c(1,1))
# dev.off()

# setps(RGraphCTDMHIcoplot02, h=4, w=5)
# setpdf(RGraphCTDMHIcoplot02, h=4, w=5)
# par(mfrow = c(1,1))
coplot(FBS2~FBS1 | Therapy*Age)
# par(mfrow = c(1,1))
# dev.off()


#
setps(RGraphCTDMHIpairs, h=6, w=6)
# setpdf(RGraphCTDMHIpairs, h=6, w=6)
par(mfrow = c(1,1))
data(state)
pairs(state.x77[,1:5], main="pairs() and pael=smooth",
      pch=16, panel=panel.smooth, lwd=1.5)
par(mfrow = c(1,1))
dev.off()



##################################################
# SECTION
# low-level ALL plots

x <- 1:30
z <- x^2
y <- (2+rnorm(x)) + (4+rnorm(x))*z + (rnorm(x)*sd(z))

##
setps(RGraphCTDMLLALL, h=6, w=6)
# setpdf(RGraphCTDMLLALL, h=6, w=6)
par(mfrow = c(3,3))

###########
# 1 points()
plot(x,y, type="n", axes=TRUE, ann=FALSE)
points(x,y,pch=1,cex=1)
title(main="points")

# 2 lines
plot(x,y, type="n", axes=TRUE, ann=FALSE)
points(x,y,pch=1,cex=1)
lines(x,y,lty=1, lwd=1.5)
title(main="lines")

# 3 abline
plot(x,y, type="n", axes=TRUE, ann=FALSE)
points(x,y,pch=1,cex=1)
abline(2,100, lty=1, lwd=1.5)
abline(h=1000, lwd=1.5)
abline(v=10, lwd=1.5)
abline(lm(y~x), lty=2)
title(main="abline")

# 4 text
plot(x,y, type="n", axes=TRUE, ann=FALSE)
text(x,y, labels=as.character(c(1:30)),cex=0.8)
title(main="text")

# 5 symbols
plot(x,y, type="n", axes=TRUE, ann=FALSE)
symbols(x,y, circles=(c(1:30)/15.0), inch=FALSE, lwd=1.5,  add=TRUE)
title(main="symbols")

# 6 segments
plot(x,y, type="n", axes=TRUE, ann=FALSE)
segments(c(1:30), rep(0,30), x, y, lwd=1.5)
title(main="segments")

# 7 arrows
x.arrow<-seq(1,30,by=3)
plot(x.arrow, x.arrow, type="n", axes=TRUE, ann=FALSE)
arrows(x.arrow, rep(15,10), x.arrow, x.arrow, lwd=1.5, length=0.1, code=2)
title(main="arrows")

# 8 ploygon
plot(x,y, type="n", axes=TRUE, ann=FALSE)
polygon(c(1,15,20,30,15), c(1000, 100, 2000, 1500, 3000), lwd=1.5)
title(main="polygon")

# 9 box
plot(x,y, type="n", axes=TRUE, ann=FALSE)
box(which="plot", lty=1, lwd=1.5, bty="o")
box(which="figure", lty=2, lwd=2.0, bty="o")
title(main="box")

#######
par(mfrow = c(1,1))
dev.off()




##########################
# Low-Level Arguments
CTDM.df<-read.table("CTDMInsu.csv", header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)


setps(RGraphCTDMLLArg, h=6, w=4)
# setpdf(RGraphCTDMLLArg, h=6, w=4)
par(mfrow = c(2,1))

# default
plot(TC1, TC2-TC1)

# plus some common arguments
plot(TC1, TC2-TC1,
       type="n",
       bty="o",
       xlim=c(200, 350), ylim = c(-100, 50),
       axes=FALSE,
       ann=FALSE,
       frame.plot=FALSE
       )
points(TC1[Therapy==1], (TC2-TC1)[Therapy==1], pch=1)
points(TC1[Therapy==2], (TC2-TC1)[Therapy==2], pch=15)

TC11<-TC1[Therapy==1]
TC12<-TC1[Therapy==2]
TC.diff1<-TC2[Therapy==1]-TC1[Therapy==1]
TC.diff2<-TC2[Therapy==2]-TC1[Therapy==2]
lines(TC11[order(TC11)],TC.diff1[order(TC11)], lty=1, lwd=1.5)
lines(TC12[order(TC12)],TC.diff2[order(TC12)], lty=2, lwd=1.5)

abline(lm(TC.diff1~TC11), lty=1, lwd=1)
abline(lm(TC.diff2~TC12), lty=2, lwd=1)

axis(1, labels=c("200mg", "250mg", "300mg", "350mg"), at=c(200, 250, 300, 350))
axis(2, labels=c("-100mg", "-50mg", "0mg", "50mg"), at=c(-100, -50, 0, 50), las=3)

title(main="TC difference vs. TC at baseline",
      sub="Low-Level example",
      xlab="TC at baseline",
      ylab="TC difference")
mtext("adding texts", side=4, cex=1.2, las=3)

legend(275, 50, legend=c("1=Synthetic", "2=Regular"), pch=c(1,15), lty=c(1,2),
       title="Insulin")

box(which="plot", lty=1, lwd=1.5, bty="o")
box(which="figure", lty=2, lwd=1.5, bty="o")
par(mfrow = c(1,1))
dev.off()


###################################
# subsection
# interaction

# Low-Level Arguments
CTDM.df<-read.table("CTDMInsu.csv", header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)

plot(TC1, TC2-TC1)
locator(5, type="p", pch=15, cex=1.5)
text(locator(2), "Outlier", adj=0)

identify(250, 0, labels="id", pos=TRUE)



###################################
# SECTION
# Graphics Parameters with \code{par()} Function
setps(RGraphAnatomy, h=3, w=4)
# setpdf(RGraphAnatomy, h=3, w=4)

par(mfrow = c(1,1))

par(oma=rep(3, 4), bg="white")
plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
box("outer", col="black", lwd=5)
# set clipping to figure region
par(xpd=TRUE)
# deliberately draw a stupidly large rectangle
rect(-1, -1, 2, 2, col="grey")
box("figure", lwd=3)
# set clipping back to plot region
par(xpd=FALSE)
# deliberately draw a stupidly large rectangle
rect(-1, -1, 2, 2, col="grey100")
box("plot", lty="dashed", lwd=2)
text(.5, .5, "Plot Region")
title(main="Title", sub="Subtitle", adj=0.3)
mtext("Figure Region", side=3, line=2)
for (i in 1:4)
    mtext(paste("Outer margin", i), side=i, line=1, outer=TRUE)

for (i in 1:4)
    mtext(paste("Margin", i), side=i, line=1, outer=FALSE)

par(mfrow = c(1,1))
dev.off()



###########################
###################################

# USE R and save as pdf or ps file
# no use setps or setpdf

setps(RGraphAnatomyMF, h=3, w=4)
# setpdf(RGraphAnatomyMF, h=3, w=4)

par(mfrow = c(1,1))

par(oma=rep(3, 4), mfrow=c(3,2), bg="white")
for (i in 1:6) {
    if (i == 3) {
      omar <- par(mar=c(2.5, 2.5, 2.5, 2.5))
      plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
      par(xpd=TRUE)
      rect(-1, -1, 2, 2, col="grey100")
      box("figure", lwd=2)
      par(xpd=FALSE)
      rect(-1, -1, 2, 2, col="grey80")
      box("plot", lty="dashed", lwd=2)
      text(.5, .5, "Current Plot Region", cex=1.5)
      mtext("Current Figure Region", side=3)
      for (i in 1:4)
      mtext(paste("Margin", i), side=i, line=1, , cex=0.8, outer=FALSE)

      par(omar)
    } else if (i == 2) {
      omar <- par(mar=c(3.5, 3.5, 3.5, 3.5))
      plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
      par(xpd=TRUE)
      rect(-1, -1, 2, 2, col="grey100")
      box("figure", lwd=2)
      par(xpd=FALSE)
      rect(-1, -1, 2, 2, col="grey80")
      box("plot", lty="dashed", lwd=2)
      text(.5, .5, "Current Plot Region", cex=1.5)
      # mtext("Current Figure Region", side=3)
      for (i in 1:4)
      mtext(paste("mar[", i,"]"), side=i, line=1, cex=1.0, outer=FALSE)

      par(omar)
       } else if  (i == 5) {
      omar <- par(mar=c(3.5, 3.5, 3.5, 3.5))
      plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
      par(xpd=TRUE)
      rect(-1, -1, 2, 2, col="grey100")
      box("figure", lwd=2)
      par(xpd=FALSE)
      rect(-1, -1, 2, 2, col="grey80")
      box("plot", lty="dashed", lwd=2)
      # text(.5, .5, "Current Plot Region", cex=1.5)
      # abline(h=0.3)
      # text(0.5, 0.1, "pin[1]", cex=1.2)
      # abline(v=0.2)
      # text(0.1, 0.8, "pin[2]", cex=1.2, srt=90)
      mtext("pin[1]", side=1, line=1)
      mtext("<-----", side=1, line=1, adj=0)
      mtext("----->", side=1, line=1, adj=1)
      mtext("pin[2]", side=2, line=1)
      mtext("<--", side=2, line=1, adj=0)
      mtext("-->", side=2, line=1, adj=1)
      
      # mtext("Current Figure Region", side=3)
      # for (i in 1:4)
      # mtext(paste("mar[", i,"]"), side=i, line=1, cex=1.0, outer=FALSE)

      par(omar)
       } else if  (i == 6) {
      omar <- par(mar=c(3.5, 3.5, 3.5, 3.5))
      plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
      par(xpd=TRUE)
      rect(-1, -1, 2, 2, col="grey100")
      box("figure", lwd=2)
      par(xpd=FALSE)
      rect(-1, -1, 2, 2, col="grey80")
      box("plot", lty="dashed", lwd=2)
      # text(.5, .5, "Current Plot Region", cex=1.5)
      # abline(h=0.3)
      # text(0.5, 0.1, "pin[1]", cex=1.2)
      # abline(v=0.2)
      # text(0.1, 0.8, "pin[2]", cex=1.2, srt=90)
      par(xpd=TRUE)
      mtext("fin[1]", side=1, line=1)
      mtext("<----------", side=1, line=1, adj=-0.3)
      mtext("---------->", side=1, line=1, adj=1.3)
      mtext("fin[2]", side=2, line=1)
      mtext("<----", side=2, line=1, adj=-0.5)
      mtext("---->", side=2, line=1, adj=1.5)

      # mtext("Current Figure Region", side=3)
      # for (i in 1:4)
      # mtext(paste("mar[", i,"]"), side=i, line=1, cex=1.0, outer=FALSE)

      par(omar)
       } else {
      omar <- par(mar=rep(0, 4))
      plot(c(0, 1), c(0, 1), type="n", ann=FALSE, axes=FALSE)
      par(xpd=TRUE)
      rect(-1, -1, 2, 2, col="grey90")
      box("figure")
      text(.5, .5, paste("Figure", i), cex=1.5)
      par(omar)
    }
}
box("outer", col="grey", lwd=3)
for (i in 1:2)
    mtext(paste("Outer margin", i, "(omi[", i, "])"), side=i, line=1, outer=TRUE)
      mtext("din[1]", side=3, line=1, outer=TRUE)
      mtext("<--------------------", side=3, line=1, adj=0, outer=TRUE)
      mtext("-------------------->", side=3, line=1, adj=1, outer=TRUE)
      mtext("din[2]", side=4, line=1, outer=TRUE)
      mtext("<--------------", side=4, line=1, adj=-0, outer=TRUE)
      mtext("-------------->", side=4, line=1, adj=1, outer=TRUE)



par(mfrow = c(1,1))
dev.off()



###################################
# subsection multiple plot
CTDM.df<-read.table("CTDMInsu.csv",header=TRUE, row.names=NULL, sep=",", dec=".")
attach(CTDM.df)

par(mfrow=c(1,2))
plot(FBS1, FBS2)
plot(TC1, TC2)
par(mfrow=c(1,1))

par(mfrow=c(2,1))
plot(FBS1, FBS2)
plot(TC1, TC2)
par(mfrow=c(1,1))

par(mfrow=c(2,2))
plot(FBS1, FBS2)
plot(TC1, TC2)
plot(FBS1, TC1)
plot(FBS2, TC2)
par(mfrow=c(1,1))

par(mfcol=c(2,2))
plot(FBS1, FBS2)
plot(TC1, TC2)
plot(FBS1, TC1)
plot(FBS2, TC2)
par(mfrow=c(1,1))


###################################
# subsection

setps(RGraphAnatomyLayout, h=6, w=6)
# setpdf(RGraphAnatomyLayout, h=6, w=6)

# par(mfrow = c(3,3))

# layout()

par(bty="o")
####

layout.show.rev<-function (n = 1)
{
    oma.saved <- par("oma")
    par(oma = rep.int(0, 4))
    par(oma = oma.saved)
    o.par <- par(mar = rep.int(0, 4))
    on.exit(par(o.par))
    for (i in seq(length = n)) {
        plot(x=c(0,1), y=c(0,1),
        type="p", pch=".",
        bty="o", lwd=2.5, lty=1,
        axes=FALSE, xlab="", ylab="",
        xlim=c(0,1), ylim=c(0,1))
        box(which="plot", lwd=2.5)
        text(0.5, 0.5, i, cex=2.0)
    }
}
##########


# a
postscript("RGraphAnatomyLayout01.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout01, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout01, h=2.5, w=2.5)

layout(matrix(1:4, 2, 2))
layout.show.rev(4)
par(mfrow = c(1,1))
dev.off()

# b
postscript("RGraphAnatomyLayout02.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout02, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout02, h=2.5, w=2.5)

layout(matrix(1:6, 3, 2, byrow=TRUE))
layout.show.rev(6)
par(mfrow = c(1,1))
dev.off()


# c
postscript("RGraphAnatomyLayout03.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout03, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout03, h=2.5, w=2.5)

layout(matrix(c(1,2,3,3), 2, 2, byrow=TRUE))
layout.show.rev(3)
par(mfrow = c(1,1))
dev.off()

# d
postscript("RGraphAnatomyLayout04.ps", horizontal=FALSE, height=2.5, width=2.5)
setps(RGraphAnatomyLayout04, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout04, h=2.5, w=2.5)

layout(matrix(1:4, 2, 2, byrow=TRUE), widths=c(3,1), heights=c(1,3))
layout.show.rev(4)
par(mfrow = c(1,1))
dev.off()

# e
postscript("RGraphAnatomyLayout05.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout05, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout05, h=2.5, w=2.5)

layout(matrix(c(1,1,2,1), 2, 2), widths=c(2,1), heights=c(1,2))
layout.show.rev(2)
par(mfrow = c(1,1))
dev.off()

# f
postscript("RGraphAnatomyLayout06.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout06, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout06, h=2.5, w=2.5)

layout(matrix(c(0,1,2,3), 2, 2), widths=c(1,3), heights=c(1,3))
layout.show.rev(3)
par(mfrow = c(1,1))
dev.off()

# OLD g no use
postscript("RGraphAnatomyLayout07.ps", horizontal=FALSE, height=2.5, width=2.5)
# setps(RGraphAnatomyLayout07, h=2.5, w=2.5)
# setpdf(RGraphAnatomyLayout07, h=2.5, w=2.5)
par(mfrow = c(1,1))

## create single figure which is 5cm square
layout(matrix(1), widths=lcm(5), heights=lcm(5))
layout.show.rev(1)

par(mfrow = c(1,1))
dev.off()

##########################
# h
setps(RGraphAnatomyLayout08, h=5, w=5)
# setpdf(RGraphAnatomyLayout08, h=5, w=5)
par(mfrow = c(1,1))

 ##-- Create a scatterplot with marginal histograms -----
 def.par <- par(no.readonly = TRUE) # save default, for resetting...

     x <- pmin(3, pmax(-3, rnorm(50)))
     y <- pmin(3, pmax(-3, rnorm(50)))
     xhist <- hist(x, breaks=seq(-3,3,0.5), plot=FALSE)
     yhist <- hist(y, breaks=seq(-3,3,0.5), plot=FALSE)
     top <- max(c(xhist$counts, yhist$counts))
     xrange <- c(-3,3)
     yrange <- c(-3,3)
     nf <- layout(matrix(c(2,0,1,3),2,2,byrow=TRUE), c(3,1), c(1,3), TRUE)
     layout.show(nf)

     par(mar=c(3,3,1,1))
     plot(x, y, xlim=xrange, ylim=yrange, xlab="", ylab="")
     par(mar=c(0,3,1,1))
     barplot(xhist$counts, axes=FALSE, ylim=c(0, top), space=0)
     par(mar=c(3,0,1,1))
     barplot(yhist$counts, axes=FALSE, xlim=c(0, top), space=0, horiz=TRUE)

par(mfrow = c(1,1))
dev.off()
















###################################
###################################
###################################
###################################
# plot region
setps(RGraphAnatomyOLD, h=3, w=8)
# setpdf(RGraphAnatomyOLD, h=3, w=8)

par(mfrow = c(1,2))
par(oma=rep(3, 4), bg="white")

x<-1:10
y<-1:10
plot(x,y,
     axes=T,
     type="n",
     bty="o",
     xaxt="n", yaxt="n",
     xlab="", ylab="",
     main="TITLE", sub="SUB")
mtext("Margin 1", side=1, line=0.5, cex=1)
mtext("Margin 2", side=2, line=0.5, cex=1)
mtext("Margin 3", side=3, line=0.5, cex=1)
mtext("Margin 4", side=4, line=0.5, cex=1, srt=90)
text(c(5), c(5), labels="plot region", cex=2.0)


x<-1:10
y<-1:10
plot(x,y,
     axes=T,
     type="n",
     bty="o",
     xaxt="s", yaxt="s",
     xlab="", ylab="",
     main="TITLE", sub="SUB")
mtext("Margin 1", side=1, line=0.5)
mtext("Margin 2", side=2, line=0.5)
mtext("Margin 3", side=3, line=0.5)
mtext("Margin 4", side=4, line=0.5)
text(c(5), c(5), labels="plot region", cex=2.0)


par(mfrow = c(1,1))
dev.off()

#######################################
CTDM.df<-read.table("CTDMInsu.csv",
    header=TRUE, row.names=NULL,
    sep=",", dec=".")
CTDM.df
# attach(CTDM.df)
attach(CTDM.df)

# High-level Plot: Univariate
setps(RGraphCTDMZZZ, h=6, w=6)
# setpdf(RGraphCTDMZZZ, h=6, w=6)
par(mfrow = c(2,2))

(FBS2.table<-table(FBS2))
barplot(FBS2.table, main="FBS2") # Bar chart
pie(FBS2.table, main="FBS2")     # Pie Chart
hist(TC2)                        # Histogram
boxplot(TC2)                     # Box plot

par(mfrow = c(1,1))
dev.off()


qqnorm(TC2)         # Normal Q-Q plot
stem(seq(0,5,0.3))  # Stem-and-leaf plot



