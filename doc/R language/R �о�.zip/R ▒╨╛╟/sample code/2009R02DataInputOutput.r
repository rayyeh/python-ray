
#### edit()
x.data<-edit(data.frame())
edit(data.frame(x.data))
####


#### read.table() # read.csv()
# Data Managements
DMTKR.read.table<-read.table("DMTKRblank.dat",
  header=TRUE,
  row.names=NULL, dec=".")
DMTKR.read.table

# Data Managements
DMTKR.read.table.csv<-read.table("DMTKRcsv.csv",
  header=TRUE,
  row.names=NULL,
  sep=",", dec=".")
DMTKR.table.csv
#
DMTKRread.csv<-read.csv("DMTKRcsv.csv",
  header = TRUE,
  sep = ",",
  dec=".")
DMTKR.read.csv


########################
data()       # �d�ݤ��ظ�Ʈج[�W��
data(Orange) # ���J {R} ���ظ�Ʈج[ Orange
help(Orange)
Orange
#
library(MASS)
help(package=MASS)
data(package="MASS")     # �d�� MASS �M�󤺫ظ�Ʈج[�W��
data(VA, package="MASS") # ���J MASS �M�󤺫ظ�Ʈج[ VA
help(VA)
VA



###################
DMTKRtable$age
attach(DMTKRtable)
age
mean(age)
names(DMTKRtable)
#
detach(DMTKRtable)
age


####################
write.table(Orange, file = "Orange.csv",
  sep = ",", col.names = NA)
?write.table

library(MASS)
?write.matrix
write.matrix(Orange, file = "OrangeMASS.csv", sep = ",")


