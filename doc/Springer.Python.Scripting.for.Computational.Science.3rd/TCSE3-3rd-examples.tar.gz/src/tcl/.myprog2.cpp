1: #include <iostream.h>
2: int main (int argc, const char* argv[])
3: {
4:   cout << "Hello, World! sin(" << argv[1] << ")=" 
5:        << sin(a2f(argv[1])) << "\n";
6:   return 0;
7: }
8: 
/*
  This file, ".myprog2.cpp", is a version
  of ".myprog.cpp" where each line is numbered.
*/
