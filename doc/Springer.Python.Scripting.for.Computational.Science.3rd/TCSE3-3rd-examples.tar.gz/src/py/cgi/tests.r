./tests.verify: test performed on 2004.08.17 


#### Test: ./tests.verify running tmp.sh 
Content-type: text/html

Hello, World! The sine of 3.14 equals 0.00159265291649
should be 0.00159265291649
CPU time of tmp.sh: 0.1 seconds on hplx30 i686, Linux


#### Test: ./tests.verify running tmp.sh 
Content-type: text/html


<HTML><BODY BGCOLOR="white">
<FORM ACTION="hw2.py.cgi" METHOD="POST">
Hello, World! The sine of 
<INPUT TYPE="text" NAME="r" SIZE="10" VALUE="">
<INPUT TYPE="submit" VALUE="equals" NAME="equalsbutton"> 
</FORM></BODY></HTML>

Content-type: text/html


<HTML><BODY BGCOLOR="white">
<FORM ACTION="hw2.py.cgi" METHOD="POST">
Hello, World! The sine of 
<INPUT TYPE="text" NAME="r" SIZE="10" VALUE="3.14">
<INPUT TYPE="submit" VALUE="equals" NAME="equalsbutton"> 0.00159265291649
</FORM></BODY></HTML>

should be 0.00159265291649
CPU time of tmp.sh: 0.2 seconds on hplx30 i686, Linux


#### Test: ./tests.verify running tmp.sh 
Content-type: text/html


<HTML><BODY BGCOLOR="white">
<TITLE>Oscillator code interface</TITLE>
<IMG SRC="../../misc/figs/simviz.xfig.gif" ALIGN="left">
<FORM ACTION="simviz1.py.cgi" METHOD="POST">

<TABLE>

        <TR>
        <TD>A</TD>
        <TD><INPUT TYPE="text" NAME="A" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>c</TD>
        <TD><INPUT TYPE="text" NAME="c" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>b</TD>
        <TD><INPUT TYPE="text" NAME="b" SIZE=10 VALUE="0.7">
        </TR>
        

        <TR>
        <TD>func</TD>
        <TD><INPUT TYPE="text" NAME="func" SIZE=10 VALUE="y">
        </TR>
        

        <TR>
        <TD>m</TD>
        <TD><INPUT TYPE="text" NAME="m" SIZE=10 VALUE="1.0">
        </TR>
        

        <TR>
        <TD>w</TD>
        <TD><INPUT TYPE="text" NAME="w" SIZE=10 VALUE="6.28318530718">
        </TR>
        

        <TR>
        <TD>tstop</TD>
        <TD><INPUT TYPE="text" NAME="tstop" SIZE=10 VALUE="30.0">
        </TR>
        

        <TR>
        <TD>y0</TD>
        <TD><INPUT TYPE="text" NAME="y0" SIZE=10 VALUE="0.2">
        </TR>
        

        <TR>
        <TD>dt</TD>
        <TD><INPUT TYPE="text" NAME="dt" SIZE=10 VALUE="0.05">
        </TR>
        
</TABLE>

<INPUT TYPE="submit" VALUE="simulate and visualize" NAME="sim">
</FORM>

The oscillator program was not found so it is impossible to perform simulations
</BODY></HTML>
Content-type: text/html


<HTML><BODY BGCOLOR="white">
<TITLE>Oscillator code interface</TITLE>
<IMG SRC="../../misc/figs/simviz.xfig.gif" ALIGN="left">
<FORM ACTION="simviz1.py.cgi" METHOD="POST">

<TABLE>

        <TR>
        <TD>A</TD>
        <TD><INPUT TYPE="text" NAME="A" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>c</TD>
        <TD><INPUT TYPE="text" NAME="c" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>b</TD>
        <TD><INPUT TYPE="text" NAME="b" SIZE=10 VALUE="0.7">
        </TR>
        

        <TR>
        <TD>func</TD>
        <TD><INPUT TYPE="text" NAME="func" SIZE=10 VALUE="siny">
        </TR>
        

        <TR>
        <TD>m</TD>
        <TD><INPUT TYPE="text" NAME="m" SIZE=10 VALUE="10">
        </TR>
        

        <TR>
        <TD>w</TD>
        <TD><INPUT TYPE="text" NAME="w" SIZE=10 VALUE="6.28318530718">
        </TR>
        

        <TR>
        <TD>tstop</TD>
        <TD><INPUT TYPE="text" NAME="tstop" SIZE=10 VALUE="30.0">
        </TR>
        

        <TR>
        <TD>y0</TD>
        <TD><INPUT TYPE="text" NAME="y0" SIZE=10 VALUE="0.2">
        </TR>
        

        <TR>
        <TD>dt</TD>
        <TD><INPUT TYPE="text" NAME="dt" SIZE=10 VALUE="0.05">
        </TR>
        
</TABLE>

<INPUT TYPE="submit" VALUE="simulate and visualize" NAME="sim">
</FORM>

The oscillator program was not found so it is impossible to perform simulations

</BODY></HTML>
CPU time of tmp.sh: 0.3 seconds on hplx30 i686, Linux


#### Test: ./tests.verify running tmp.sh 
Content-type: text/html


<HTML><BODY BGCOLOR="white">
<TITLE>Oscillator code interface</TITLE>
<IMG SRC="../../misc/figs/simviz.xfig.gif" ALIGN="left">
<FORM ACTION="wrapper.sh.cgi?s=simviz1w.py.cgi" METHOD="POST">

<TABLE>

        <TR>
        <TD>A</TD>
        <TD><INPUT TYPE="text" NAME="A" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>c</TD>
        <TD><INPUT TYPE="text" NAME="c" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>b</TD>
        <TD><INPUT TYPE="text" NAME="b" SIZE=10 VALUE="0.7">
        </TR>
        

        <TR>
        <TD>func</TD>
        <TD><INPUT TYPE="text" NAME="func" SIZE=10 VALUE="y">
        </TR>
        

        <TR>
        <TD>m</TD>
        <TD><INPUT TYPE="text" NAME="m" SIZE=10 VALUE="1.0">
        </TR>
        

        <TR>
        <TD>w</TD>
        <TD><INPUT TYPE="text" NAME="w" SIZE=10 VALUE="6.28318530718">
        </TR>
        

        <TR>
        <TD>tstop</TD>
        <TD><INPUT TYPE="text" NAME="tstop" SIZE=10 VALUE="30.0">
        </TR>
        

        <TR>
        <TD>y0</TD>
        <TD><INPUT TYPE="text" NAME="y0" SIZE=10 VALUE="0.2">
        </TR>
        

        <TR>
        <TD>dt</TD>
        <TD><INPUT TYPE="text" NAME="dt" SIZE=10 VALUE="0.05">
        </TR>
        
</TABLE>

<INPUT TYPE="submit" VALUE="simulate and visualize" NAME="sim">
</FORM>

</BODY></HTML>
Content-type: text/html


<HTML><BODY BGCOLOR="white">
<TITLE>Oscillator code interface</TITLE>
<IMG SRC="../../misc/figs/simviz.xfig.gif" ALIGN="left">
<FORM ACTION="wrapper.sh.cgi?s=simviz1w.py.cgi" METHOD="POST">

<TABLE>

        <TR>
        <TD>A</TD>
        <TD><INPUT TYPE="text" NAME="A" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>c</TD>
        <TD><INPUT TYPE="text" NAME="c" SIZE=10 VALUE="5.0">
        </TR>
        

        <TR>
        <TD>b</TD>
        <TD><INPUT TYPE="text" NAME="b" SIZE=10 VALUE="0.7">
        </TR>
        

        <TR>
        <TD>func</TD>
        <TD><INPUT TYPE="text" NAME="func" SIZE=10 VALUE="siny">
        </TR>
        

        <TR>
        <TD>m</TD>
        <TD><INPUT TYPE="text" NAME="m" SIZE=10 VALUE="10">
        </TR>
        

        <TR>
        <TD>w</TD>
        <TD><INPUT TYPE="text" NAME="w" SIZE=10 VALUE="6.28318530718">
        </TR>
        

        <TR>
        <TD>tstop</TD>
        <TD><INPUT TYPE="text" NAME="tstop" SIZE=10 VALUE="30.0">
        </TR>
        

        <TR>
        <TD>y0</TD>
        <TD><INPUT TYPE="text" NAME="y0" SIZE=10 VALUE="0.2">
        </TR>
        

        <TR>
        <TD>dt</TD>
        <TD><INPUT TYPE="text" NAME="dt" SIZE=10 VALUE="0.05">
        </TR>
        
</TABLE>

<INPUT TYPE="submit" VALUE="simulate and visualize" NAME="sim">
</FORM>


</BODY></HTML>
CPU time of tmp.sh: 0.6 seconds on hplx30 i686, Linux

