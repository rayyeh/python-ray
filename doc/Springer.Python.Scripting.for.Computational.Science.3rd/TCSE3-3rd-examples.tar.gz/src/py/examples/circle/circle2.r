./circle2.verify: test performed on 2001-03-05(basunus i686 running Linux)


#### Test: ./circle2.verify running circle.py 1 0.21
-1.8 1.8 -1.8 1.8
1.0  1.3195e+00
-2.7802e-01  1.6476e+00
-9.1367e-01  4.9135e-01
 4.8177e-02 -4.1189e-01
 1.1622e+00  2.9512e-01
end
CPU time of circle.py: 0.1 seconds on basunus i686, Linux

