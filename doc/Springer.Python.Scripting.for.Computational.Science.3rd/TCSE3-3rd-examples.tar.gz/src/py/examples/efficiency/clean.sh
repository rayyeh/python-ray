#!/bin/sh
rm -f *.so *module.c *.pyc *~ matrix-f2py* *.o *_wrap.* matrix_cpp.py
