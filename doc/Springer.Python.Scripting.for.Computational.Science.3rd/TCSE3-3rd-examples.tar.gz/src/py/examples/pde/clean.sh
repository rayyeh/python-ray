#!/bin/sh
rm -rf *.so *.o build tmp* *~
