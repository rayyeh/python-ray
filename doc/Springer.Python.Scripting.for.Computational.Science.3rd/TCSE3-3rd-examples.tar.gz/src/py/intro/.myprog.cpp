#include <iostream.h>
int main (int argc, const char* argv[])
{
  cout << "Hello, World! sin(" << argv[1] << ")=" 
       << sin(a2f(argv[1])) << "\n";
  return 0;
}
