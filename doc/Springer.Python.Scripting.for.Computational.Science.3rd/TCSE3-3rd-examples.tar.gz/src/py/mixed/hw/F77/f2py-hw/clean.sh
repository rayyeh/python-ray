#!/bin/sh -x
rm -rf *~ *.so *.pyf *.o *.pyc build *.egg-info

