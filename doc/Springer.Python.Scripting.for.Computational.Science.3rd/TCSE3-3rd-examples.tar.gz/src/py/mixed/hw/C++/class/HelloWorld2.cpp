#include "HelloWorld2.h"
void HelloWorld2:: gets(double& s_) const { s_ = s; }
