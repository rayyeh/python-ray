#!/bin/sh -x
rm -fr *~ *.so *.o *_wrap.* *.pyc tmpsrc build lib
rm -f hw.py

