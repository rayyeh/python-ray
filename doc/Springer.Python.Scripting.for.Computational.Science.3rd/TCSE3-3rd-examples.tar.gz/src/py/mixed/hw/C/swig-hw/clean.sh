#!/bin/sh -x
rm -fr *~ *.so *.o *_wrap.* *.pyc tmpsrc build lib error/*_wrap* 
rm -f hw.py error/hw.py

