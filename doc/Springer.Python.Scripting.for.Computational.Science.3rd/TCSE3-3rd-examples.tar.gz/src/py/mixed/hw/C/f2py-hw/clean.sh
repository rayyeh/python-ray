#!/bin/sh
rm -f *.so *~ hw.pyf
