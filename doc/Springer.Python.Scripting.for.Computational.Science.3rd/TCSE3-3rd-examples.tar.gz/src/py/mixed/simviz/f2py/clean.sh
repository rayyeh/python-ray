#!/bin/sh -x
rm -rf *.o tmp* *.so
