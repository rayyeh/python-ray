function z = f(x, y);
z = sin(x*y) + 8*x;
