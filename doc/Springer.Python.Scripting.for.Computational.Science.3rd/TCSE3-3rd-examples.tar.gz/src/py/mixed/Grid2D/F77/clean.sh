#!/bin/sh -x
rm -rf tmp* ext_gridloop* *~ callback.so _cb.f
