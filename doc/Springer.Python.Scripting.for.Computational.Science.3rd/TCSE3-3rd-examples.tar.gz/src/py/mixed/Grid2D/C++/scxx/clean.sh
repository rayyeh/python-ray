#!/bin/sh -x
rm -f *.o *.so *~ app.tmp
