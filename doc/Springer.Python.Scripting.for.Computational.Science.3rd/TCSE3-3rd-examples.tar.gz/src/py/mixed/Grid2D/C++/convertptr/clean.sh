#!/bin/sh -x
rm -rf *.o *.so *~ tmp.app build *_wrap.* *.pyc ext_gridloop.py


