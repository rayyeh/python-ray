#!/bin/sh -x
rm -f *.o *.so *~ ext_gridloop_wrap.cxx ext_gridloop.py *.pyc
