#include <NumPyArray.h>

void gridloop1(PyArrayObject* a_, PyArrayObject* xcoor_,
               PyArrayObject* ycoor_, PyObject* func1);

PyArrayObject* gridloop2(PyArrayObject* xcoor_,
                         PyArrayObject* ycoor_, PyObject* func1);

