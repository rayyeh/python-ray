#!/bin/sh -x
rm -rf *.o *.so *~ build *.egg-info
