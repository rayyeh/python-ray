#!/bin/sh -x
rm -rf *.o *.so *~ *.egg-info build
