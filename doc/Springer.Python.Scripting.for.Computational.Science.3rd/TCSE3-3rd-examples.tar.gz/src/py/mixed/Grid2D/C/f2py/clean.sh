#!/bin/sh
rm -rf build *.so *~ *.o tmp* *.egg-info *.pyc