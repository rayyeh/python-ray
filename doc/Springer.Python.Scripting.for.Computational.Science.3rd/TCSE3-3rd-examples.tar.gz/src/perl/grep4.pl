#!/usr/bin/perl
$pattern = shift;
print grep /$pattern/, <>;



