#!/usr/bin/perl
$r = $ARGV[0];  # fetch the first ([0]) command-line argument
$s = sin($r);   # compute sin(r) and store in variable s
print "Hello, World! sin($r)=$s\n"; # print to standard output

