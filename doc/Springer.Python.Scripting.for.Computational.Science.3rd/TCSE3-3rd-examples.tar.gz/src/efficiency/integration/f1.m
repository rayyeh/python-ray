function y = f1(x)
y = exp(-x*x)*log(1+x*sin(x));

