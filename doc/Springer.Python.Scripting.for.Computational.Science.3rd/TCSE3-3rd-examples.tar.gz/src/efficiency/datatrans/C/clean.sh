#!/bin/sh
rm -rf *.o *.app *~
