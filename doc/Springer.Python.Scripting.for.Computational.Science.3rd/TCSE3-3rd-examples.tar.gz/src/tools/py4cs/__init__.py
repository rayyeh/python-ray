# load py4cs as scitools:
import scitools
import sys
sys.modules['py4cs'] = scitools
