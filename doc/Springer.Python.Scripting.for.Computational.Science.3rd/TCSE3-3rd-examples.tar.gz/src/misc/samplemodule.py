"""
This is a sample module for demo purposes.
"""
__version__ = 0.01
__author__ = 'H. P. Langtangen'
#__all__ = ['f2', 'a']

def f1():
    return 1

def f2():
    return 2

class MyClass1:
    pass

_v1 = 1.0
_v2 = f2
a = 2
b = True
c = False

